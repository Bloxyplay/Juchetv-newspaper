/* Yangshipin/CCTV video player frontend port - HTML5 player
   Self-contained UI + native video element. Optional HLS via hls.js if window.Hls is present. */
(function (global) {
  'use strict';

  var defaults = {
    id: 'ysp-player',
    src: '',
    poster: '',
    title: '',
    live: false,
    autoplay: false,
    muted: false,
    volume: 0.8,
    playbackRate: 1,
    fluid: true,
    watermark: true,
    controls: true,
    onNext: null,
    onEnded: null,
    onError: null
  };

  function $(root, sel) { return root.querySelector(sel); }
  function create(tag, cls) { var el = document.createElement(tag); if (cls) el.className = cls; return el; }
  function fmtTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    sec = Math.floor(sec);
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    var mm = (m < 10 ? '0' : '') + m, ss = (s < 10 ? '0' : '') + s;
    return h > 0 ? (h + ':' + mm + ':' + ss) : (mm + ':' + ss);
  }

  function YspPlayer(options) {
    this.config = Object.assign({}, defaults, options || {});
    this.container = typeof this.config.id === 'string' ? document.getElementById(this.config.id) : this.config.id;
    if (!this.container) throw new Error('YspPlayer: container not found');
    this.isPlaying = false;
    this.isFullscreen = false;
    this.dragging = false;
    this._timers = {};
    this._build();
    this._bind();
    this._load();
  }

  YspPlayer.prototype._build = function () {
    var c = this.container;
    c.classList.add('ysp-player');
    c.innerHTML = '';

    this.video = create('video', 'ysp-video');
    this.video.playsInline = true;
    this.video.controls = false;
    this.video.preload = 'metadata';
    this.video.muted = !!this.config.muted;
    this.video.volume = this.config.volume;
    this.video.playbackRate = this.config.playbackRate;
    if (this.config.poster) this.video.poster = this.config.poster;
    c.appendChild(this.video);

    if (this.config.poster && !this.config.autoplay) {
      this.poster = create('div', 'ysp-poster');
      this.poster.innerHTML = '<img class="poster-cover" src="' + this.config.poster + '" alt=""><img class="poster-play" src="assets/playerimg/poster_play.png" alt="play">';
      c.appendChild(this.poster);
    }

    this.loading = create('div', 'ysp-loading');
    this.loading.innerHTML = '<img class="pic-loading" src="assets/playerimg/loading_spinner.png" alt=""><div class="txt">全力加载中…</div>';
    c.appendChild(this.loading);

    this.replay = create('div', 'ysp-replay');
    this.replay.innerHTML = '<img src="assets/playerimg/replay.png" alt=""><div>重新播放</div>';
    c.appendChild(this.replay);

    this.error = create('div', 'ysp-error');
    this.error.innerHTML = '<div style="font-size:14px">视频加载失败，请稍后重试</div>';
    c.appendChild(this.error);

    this.topbar = create('div', 'ysp-topbar');
    this.topbar.innerHTML = (this.config.live ? '<span class="ysp-live-badge">直播</span>' : '') + '<div class="ysp-title">' + (this.config.title || '') + '</div>';
    c.appendChild(this.topbar);

    if (this.config.watermark) {
      var wm = create('div', 'ysp-watermark');
      wm.innerHTML = '<img src="assets/playerimg/logo.png" alt="央视频">';
      c.appendChild(wm);
    }

    if (this.config.controls) {
      this.controls = create('div', 'ysp-controls');
      this.controls.innerHTML =
        '<div class="ysp-full-control-btnl">' +
          '<span class="ysp-btn ysp-play play" title="播放/暂停"></span>' +
          (this.config.onNext ? '<span class="ysp-btn ysp-next" title="下一集"></span>' : '') +
        '</div>' +
        '<div class="ysp-time"><span class="cur">00:00</span> / <span class="dur">00:00</span></div>' +
        '<div class="ysp-progress"><div class="ysp-progress-track"><div class="ysp-progress-buffer"></div><div class="ysp-progress-played"></div><div class="ysp-progress-dot"></div></div></div>' +
        '<div class="ysp-btn ysp-volume on" title="音量"><div class="ysp-volume-panel"><div class="ysp-volume-rail"><div class="ysp-volume-level"></div><div class="ysp-volume-dot"></div></div></div></div>' +
        '<div class="ysp-speed">1X<div class="ysp-speed-panel">' +
          ['0.5X','1X','1.25X','1.5X','2X'].map(function(s){return '<div class="ysp-speed-item" data-rate="'+s.replace('X','')+'">'+s+'</div>';}).join('') +
        '</div></div>' +
        '<div class="ysp-btn ysp-pip" title="画中画"></div>' +
        '<div class="ysp-full-control-btnr"><span class="ysp-btn ysp-fullscreen enter" title="全屏"></span></div>';
      c.appendChild(this.controls);
    }

    this.blackBg = create('div', 'ysp-black-bg');
    c.appendChild(this.blackBg);
  };

  YspPlayer.prototype._bind = function () {
    var self = this, v = this.video, c = this.container;

    if (this.poster) this.poster.addEventListener('click', function () { self.play(); });
    this.replay.addEventListener('click', function () { self.replay.classList.remove('show'); self.seek(0); self.play(); });

    v.addEventListener('play', function () { self.isPlaying = true; self._setPlayIcon(true); self._autoHideControls(); });
    v.addEventListener('pause', function () { self.isPlaying = false; self._setPlayIcon(false); self._showControls(); });
    v.addEventListener('loadstart', function () { self.loading.classList.add('show'); });
    v.addEventListener('waiting', function () { self.loading.classList.add('show'); });
    v.addEventListener('playing', function () { self.loading.classList.remove('show'); self.blackBg.classList.remove('show'); });
    v.addEventListener('canplay', function () { self.loading.classList.remove('show'); });
    v.addEventListener('loadedmetadata', function () { self._updateTime(); });
    v.addEventListener('timeupdate', function () { if (!self.dragging) self._updateProgress(); self._updateTime(); });
    v.addEventListener('progress', function () { self._updateBuffer(); });
    v.addEventListener('volumechange', function () { self._updateVolume(); });
    v.addEventListener('ratechange', function () { self._updateSpeed(); });
    v.addEventListener('ended', function () {
      if (self.config.live) return;
      self._showReplay();
      if (typeof self.config.onEnded === 'function') self.config.onEnded();
    });
    v.addEventListener('error', function () {
      self.loading.classList.remove('show');
      self.error.classList.add('show');
      var msg = v.error ? ('CODE:' + v.error.code + ' ' + (v.error.message || '')) : 'unknown error';
      self.error.innerHTML = '<div style="font-size:14px">视频加载失败</div><div style="font-size:11px;margin-top:6px;opacity:.8">' + msg + '</div>';
      if (typeof self.config.onError === 'function') self.config.onError(v.error);
    });
    v.addEventListener('click', function () { self.toggle(); });
    v.addEventListener('dblclick', function () { self.toggleFullscreen(); });

    document.addEventListener('fullscreenchange', function () {
      self.isFullscreen = document.fullscreenElement === c;
      self._setFullscreenIcon();
    });

    if (this.controls) {
      $('.ysp-play', this.controls).addEventListener('click', function (e) { e.stopPropagation(); self.toggle(); });
      var next = $('.ysp-next', this.controls);
      if (next) next.addEventListener('click', function (e) { e.stopPropagation(); if (typeof self.config.onNext === 'function') self.config.onNext(); });
      $('.ysp-fullscreen', this.controls).addEventListener('click', function (e) { e.stopPropagation(); self.toggleFullscreen(); });
      $('.ysp-pip', this.controls).addEventListener('click', function (e) { e.stopPropagation(); self.togglePip(); });
      $('.ysp-volume', this.controls).addEventListener('click', function (e) { e.stopPropagation(); self.toggleMute(); });

      var progress = $('.ysp-progress', this.controls);
      var track = $('.ysp-progress-track', this.controls);
      function seekFromEvent(e) {
        var rect = track.getBoundingClientRect();
        var x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
        var p = Math.min(1, Math.max(0, x / rect.width));
        self.seek(p * (v.duration || 0));
      }
      progress.addEventListener('mousedown', function (e) { self.dragging = true; seekFromEvent(e); });
      progress.addEventListener('mousemove', function (e) { if (self.dragging) seekFromEvent(e); });
      document.addEventListener('mouseup', function () { self.dragging = false; });
      progress.addEventListener('touchstart', function (e) { self.dragging = true; seekFromEvent(e); }, {passive:true});
      progress.addEventListener('touchmove', function (e) { if (self.dragging) seekFromEvent(e); }, {passive:true});
      progress.addEventListener('touchend', function () { self.dragging = false; });

      var rail = $('.ysp-volume-rail', this.controls);
      function volumeFromEvent(e) {
        var rect = rail.getBoundingClientRect();
        var y = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
        var p = Math.min(1, Math.max(0, 1 - y / rect.height));
        v.muted = false;
        v.volume = p;
      }
      rail.addEventListener('mousedown', function (e) { volumeFromEvent(e); });
      rail.addEventListener('mousemove', function (e) { if (e.buttons) volumeFromEvent(e); });
      rail.addEventListener('touchstart', function (e) { volumeFromEvent(e); }, {passive:true});

      var speedItems = this.controls.querySelectorAll('.ysp-speed-item');
      for (var i = 0; i < speedItems.length; i++) {
        speedItems[i].addEventListener('click', function (e) {
          e.stopPropagation();
          v.playbackRate = parseFloat(this.getAttribute('data-rate'));
        });
      }
    }

    c.addEventListener('mousemove', function () { self._autoHideControls(); });
    c.addEventListener('mouseleave', function () { if (self.isPlaying) self._hideControlsSoon(); });
  };

  YspPlayer.prototype._load = function () {
    var src = this.config.src;
    if (!src) { this.loading.classList.remove('show'); this.error.classList.add('show'); this.error.innerHTML = '<div style="font-size:14px">请填写视频地址</div>'; return; }
    if (/\.m3u8($|\?)/i.test(src) && !this.video.canPlayType('application/vnd.apple.mpegurl') && global.Hls && global.Hls.isSupported()) {
      var self = this;
      this.hls = new global.Hls({ enableWorker: true });
      this.hls.loadSource(src);
      this.hls.attachMedia(this.video);
      this.hls.on(global.Hls.Events.MANIFEST_PARSED, function () { if (self.config.autoplay) self.play(); });
      this.hls.on(global.Hls.Events.ERROR, function (event, data) {
        if (data && data.fatal && typeof self.config.onError === 'function') self.config.onError(data);
      });
    } else {
      this.video.src = src;
      if (this.config.autoplay) this.play();
    }
  };

  YspPlayer.prototype.play = function () {
    if (this.poster) { this.poster.parentNode && this.poster.parentNode.removeChild(this.poster); this.poster = null; }
    var p = this.video.play();
    if (p && p.catch) p.catch(function(){});
  };
  YspPlayer.prototype.pause = function () { this.video.pause(); };
  YspPlayer.prototype.toggle = function () { if (this.video.paused) this.play(); else this.pause(); };
  YspPlayer.prototype.seek = function (sec) { try { this.video.currentTime = sec; } catch(e){} this._updateProgress(); };
  YspPlayer.prototype.setVolume = function (val) { this.video.muted = false; this.video.volume = Math.min(1, Math.max(0, val)); };
  YspPlayer.prototype.toggleMute = function () { this.video.muted = !this.video.muted; };
  YspPlayer.prototype.setRate = function (rate) { this.video.playbackRate = rate; };
  YspPlayer.prototype.toggleFullscreen = function () {
    var c = this.container;
    if (!this.isFullscreen) {
      if (c.requestFullscreen) c.requestFullscreen();
      else if (c.webkitRequestFullscreen) c.webkitRequestFullscreen();
    } else {
      if (document.exitFullscreen) document.exitFullscreen();
      else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    }
  };
  YspPlayer.prototype.togglePip = function () {
    var v = this.video;
    if (document.pictureInPictureElement) { document.exitPictureInPicture(); return; }
    if (v.requestPictureInPicture) v.requestPictureInPicture().catch(function(){});
  };
  YspPlayer.prototype.destroy = function () {
    if (this.hls) { this.hls.destroy(); this.hls = null; }
    this.video.pause();
    this.video.removeAttribute('src');
    this.video.load();
    this.container.innerHTML = '';
    this.container.classList.remove('ysp-player');
  };

  YspPlayer.prototype._setPlayIcon = function (playing) {
    if (!this.controls) return;
    var btn = $('.ysp-play', this.controls);
    btn.className = 'ysp-btn ysp-play ' + (playing ? 'pause' : 'play');
  };
  YspPlayer.prototype._setFullscreenIcon = function () {
    if (!this.controls) return;
    var btn = $('.ysp-fullscreen', this.controls);
    btn.className = 'ysp-btn ysp-fullscreen ' + (this.isFullscreen ? 'exit' : 'enter');
  };
  YspPlayer.prototype._updateTime = function () {
    if (!this.controls) return;
    $('.cur', this.controls).textContent = fmtTime(this.video.currentTime);
    $('.dur', this.controls).textContent = this.config.live ? '直播' : fmtTime(this.video.duration);
  };
  YspPlayer.prototype._updateProgress = function () {
    if (!this.controls) return;
    var d = this.video.duration || 0;
    var p = d ? (this.video.currentTime / d) * 100 : 0;
    $('.ysp-progress-played', this.controls).style.width = p + '%';
    $('.ysp-progress-dot', this.controls).style.left = p + '%';
  };
  YspPlayer.prototype._updateBuffer = function () {
    if (!this.controls || !this.video.buffered.length) return;
    var end = this.video.buffered.end(this.video.buffered.length - 1);
    var d = this.video.duration || 0;
    $('.ysp-progress-buffer', this.controls).style.width = (d ? (end / d) * 100 : 0) + '%';
  };
  YspPlayer.prototype._updateVolume = function () {
    if (!this.controls) return;
    var vol = this.video.muted ? 0 : this.video.volume;
    var btn = $('.ysp-volume', this.controls);
    btn.className = 'ysp-btn ysp-volume ' + (vol > 0 ? 'on' : 'off');
    $('.ysp-volume-level', this.controls).style.height = (vol * 100) + '%';
    $('.ysp-volume-dot', this.controls).style.bottom = (vol * 100) + '%';
  };
  YspPlayer.prototype._updateSpeed = function () {
    if (!this.controls) return;
    var rate = this.video.playbackRate;
    $('.ysp-speed', this.controls).childNodes[0].textContent = rate + 'X';
    var items = this.controls.querySelectorAll('.ysp-speed-item');
    for (var i = 0; i < items.length; i++) items[i].classList.toggle('active', parseFloat(items[i].getAttribute('data-rate')) === rate);
  };
  YspPlayer.prototype._showReplay = function () { this.replay.classList.add('show'); };
  YspPlayer.prototype._showControls = function () { if (this.controls) this.controls.classList.add('show'); };
  YspPlayer.prototype._hideControlsSoon = function () {
    var self = this;
    clearTimeout(this._timers.controls);
    this._timers.controls = setTimeout(function () { if (self.controls) self.controls.classList.remove('show'); }, 2500);
  };
  YspPlayer.prototype._autoHideControls = function () {
    this._showControls();
    if (this.isPlaying) this._hideControlsSoon();
  };

  global.YspPlayer = YspPlayer;
  if (typeof module !== 'undefined' && module.exports) module.exports = YspPlayer;
})(typeof window !== 'undefined' ? window : this);
